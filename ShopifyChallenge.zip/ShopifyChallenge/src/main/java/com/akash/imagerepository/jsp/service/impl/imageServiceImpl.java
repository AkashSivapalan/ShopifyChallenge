package com.akash.imagerepository.jsp.service.impl;

import com.akash.imagerepository.jsp.dto.image;
import com.akash.imagerepository.jsp.exception.DuplicateImageException;
import com.akash.imagerepository.jsp.repository.model.imageData;
import com.akash.imagerepository.jsp.service.imageService;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class imageServiceImpl implements imageService {
    private final com.akash.imagerepository.jsp.repository.ImageRepository imageRepository;

public imageServiceImpl(com.akash.imagerepository.jsp.repository.ImageRepository imageRepository){
    this.imageRepository =imageRepository;
}

    @Override
    public Collection<image> getImages(){
        return imageRepository.findAll()
                .stream()
                .map(imageServiceImpl::convertImageData)
                .collect(Collectors.toList());
    }

    @Override
    public image addImage(image Image) {
        final Optional<imageData> existingImage = imageRepository.findByTag(Image.getImageTag());
        if (existingImage.isPresent()) {
            throw new DuplicateImageException(Image);
        }

        final imageData savedImage = imageRepository.add(convertImage(Image));
        return convertImageData(savedImage);
    }

    @Override
    public image removeImage(image Image) {
        final Optional<imageData> existingImage = imageRepository.findByTag(Image.getImageTag());
        if (existingImage.isPresent()) {
            final imageData savedImage = imageRepository.remove(convertImage(Image));
            return convertImageData(savedImage);
        }else{
            throw new DuplicateImageException(Image);
        }
    }

    private static image convertImageData(imageData ImageData) {
        return new image(ImageData.getName(), ImageData.getSize(), ImageData.getImageTag());
    }

    private static imageData convertImage(image Image) {
        return new imageData(Image.getName(), Image.getSize(), Image.getImageTag());
    }
}

package com.akash.imagerepository.jsp.repository.model;

public class imageData {
    private String name;
    private int size;
    private String imageTag;

    public imageData(String name, int size, String imageTag) {
        this.name = name;
        this.size = size;
        this.imageTag = imageTag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getImageTag() {
        return imageTag;
    }

    public void setImageTag(String imageTag) {
        this.imageTag = imageTag;
    }
}

package com.akash.imagerepository.jsp.controller;

import com.akash.imagerepository.jsp.dto.image;
import com.akash.imagerepository.jsp.repository.model.imageData;
import com.akash.imagerepository.jsp.service.imageService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/image")
public class imageController {
    private final imageService ImageService;

    public imageController(imageService imageService) {
        ImageService = imageService;
    }

    @GetMapping("/viewRepository")
    public String viewRepository(Model model) {
        model.addAttribute("images", ImageService.getImages());
        return "ViewRepository";
    }

    @GetMapping("/findImage")
    public String searchImage(Model model) {
        String search = "";
        model.addAttribute("str", search);
        return "findImage";
    }

    @GetMapping("/addImage")
    public String addImageView(Model model) {
        model.addAttribute("image", new image());
        return "AddImage";
    }

    @GetMapping("/deleteImage")
    public String deleteImageView(Model model) {
        model.addAttribute("image", new image());
        return "deleteImage";
    }

    @PostMapping("/addImage")
    public RedirectView addImage(@ModelAttribute("image") image Image, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/image/addImage", true);
        image savedImage = ImageService.addImage(Image);
        redirectAttributes.addFlashAttribute("savedImage", savedImage);
        redirectAttributes.addFlashAttribute("addImageSuccess", true);
        return redirectView;
    }

    @PostMapping("/deleteImage")
    public RedirectView deleteImage(@ModelAttribute("image") image Image, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/image/deleteImage", true);
        image savedImage = ImageService.removeImage(Image);
        redirectAttributes.addFlashAttribute("savedImage", savedImage);
        redirectAttributes.addFlashAttribute("deleteImageSuccess", true);
        return redirectView;
    }

    @PostMapping("/findImage")
    public RedirectView deleteImage(@ModelAttribute("str") String search, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/image/findImage", true);

        System.out.println(search);

        ArrayList<imageData> initData = new ArrayList<imageData>();
        initData.add(new imageData("frontendservice", 975, "ABCDEF"));
        initData.add(new imageData("frontenddb", 1500, "GHIJKL"));
        initData.add(new imageData("moviesdb", 4000, "MNOPQR"));

        ArrayList<imageData> searchQueries = new ArrayList<>();
        for (imageData item : initData) {
            if (item.getName().contains(search)) {
                searchQueries.add(item);

                for (imageData x : searchQueries) {
                    System.out.println("h vhjvj");
                }
            }
        }
        int num = searchQueries.size();
        System.out.println("" + num);
        if (num > 0) {
            redirectAttributes.addFlashAttribute("searchData", searchQueries);
            redirectAttributes.addFlashAttribute("searchImageSuccess", true);
            return redirectView;
        }
        else{
            redirectAttributes.addFlashAttribute("searchImageSuccess", false);
            return redirectView;
        }

    }
}

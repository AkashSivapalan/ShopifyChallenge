package com.akash.imagerepository.jsp.repository;

import com.akash.imagerepository.jsp.repository.model.imageData;

import java.util.Collection;
import java.util.Optional;

public interface ImageRepository {
    Collection <imageData> findAll();

    Optional<imageData> findByTag(String imageTag);

    imageData add(imageData image);
    imageData remove(imageData image);
}

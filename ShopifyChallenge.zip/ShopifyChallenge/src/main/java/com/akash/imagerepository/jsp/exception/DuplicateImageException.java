package com.akash.imagerepository.jsp.exception;

import com.akash.imagerepository.jsp.dto.image;
import lombok.Getter;

@Getter
public class DuplicateImageException extends RuntimeException{
    private final image Image;

    public DuplicateImageException(image Image) {
        this.Image = Image;
    }
}

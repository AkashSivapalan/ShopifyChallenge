package com.akash.imagerepository.jsp.repository.impl;

import com.akash.imagerepository.jsp.repository.ImageRepository;
import com.akash.imagerepository.jsp.repository.model.imageData;

import java.util.*;

public class InMemoryImageRepository implements ImageRepository {
    private final Map<String, imageData> storedImages;

    public InMemoryImageRepository(Map<String, imageData> storedImages) {
        this.storedImages = new HashMap<>();
        this.storedImages.putAll(storedImages);
    }

    @Override
    public Collection<imageData> findAll() {
        if (storedImages.isEmpty()) {
            return Collections.emptyList();
        }
        return storedImages.values();
    }

    @Override
    public Optional<imageData> findByTag(String tag) {
        return Optional.ofNullable(storedImages.get(tag));
    }

    @Override
    public imageData add(imageData image) {
        storedImages.put(image.getImageTag(), image);
        return image;
    }
    @Override
    public imageData remove(imageData image) {
        storedImages.remove(image.getImageTag());
        return image;
    }
}

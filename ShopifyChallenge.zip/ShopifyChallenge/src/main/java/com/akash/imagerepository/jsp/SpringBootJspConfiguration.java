package com.akash.imagerepository.jsp;

import com.akash.imagerepository.jsp.repository.ImageRepository;
import com.akash.imagerepository.jsp.repository.impl.InMemoryImageRepository;
import com.akash.imagerepository.jsp.repository.model.imageData;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class SpringBootJspConfiguration {

    @Bean
    public ImageRepository provideBookRepository() {
        return new InMemoryImageRepository(initialImageData());
    }

    private static Map<String, imageData> initialImageData() {
        Map<String, imageData> initData = new HashMap<>();
        initData.put("ABCDEF", new imageData("frontendservice", 975, "ABCDEF"));
        initData.put("GHIJKL", new imageData("frontenddb", 1500, "GHIJKL"));
        initData.put("MNOPQR", new imageData("moviesdb", 4000, "MNOPQR"));
        return initData;
    }


}

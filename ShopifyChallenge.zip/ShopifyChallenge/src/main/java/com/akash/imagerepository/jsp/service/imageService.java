package com.akash.imagerepository.jsp.service;
import com.akash.imagerepository.jsp.dto.image;
import java.util.Collection;

public interface imageService {
    Collection<image> getImages();

    image addImage(image Image);
    image removeImage(image Image);

}

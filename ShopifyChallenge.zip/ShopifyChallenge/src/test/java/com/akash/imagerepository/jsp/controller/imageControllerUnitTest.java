package com.akash.imagerepository.jsp.controller;

import com.akash.imagerepository.jsp.dto.image;
import com.akash.imagerepository.jsp.repository.model.imageData;
import com.akash.imagerepository.jsp.service.imageService;
import org.junit.jupiter.api.Test;
import org.mockito.AdditionalAnswers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;


import java.awt.print.Book;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;

@SpringBootTest
class imageControllerUnitTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private imageService ImageService;

    @Test
    public void viewRepository() throws Exception{
        when(ImageService.getImages()).thenReturn(existingImages());
        ResultActions viewImagesResult = mockMvc.perform(get("/image/viewRepository"));

        viewImagesResult.andExpect(view().name("ViewRepository"))
                .andExpect(model().attribute("images", hasSize(3)));
    }

    @Test
    public void addImageView() throws Exception{
        ResultActions addImageViewResult = mockMvc.perform(get("/image/addImage"));

        addImageViewResult.andExpect(view().name("SearchImage"))
                .andExpect(model().attribute("image", isA(image.class)));
    }

    @Test
    public void addImage() throws Exception {
        when(ImageService.addImage(any(image.class))).thenAnswer(AdditionalAnswers.returnsFirstArg());
        MockHttpServletRequestBuilder addImageRequest = MockMvcRequestBuilders.post("/image/addImage")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                .param("name", "gamesService")
                .param("size", String.valueOf(1000))
                .param("imageTag", "ABCD");
        ResultActions addBookResult = mockMvc.perform(addImageRequest);

        addBookResult.andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/image/addImage"))
                .andExpect(flash().attribute("savedImage", hasProperty("imageTag", equalTo("ABCD"))))
                .andExpect(flash().attribute("addImageSuccess", true));
    }

    private static Collection<image> existingImages() {
        List<image> images = new ArrayList<>();
        images.add(new image("frontendservice", 975, "ABCDEF"));
        images.add(new image("frontenddb", 1500, "GHIJKL"));
        images.add(new image("moviesdb", 4000, "MNOPQR"));
        return images;
    }
}
package com.akash.imagerepository.jsp.controller;

import com.akash.imagerepository.jsp.repository.ImageRepository;
import com.akash.imagerepository.jsp.repository.impl.InMemoryImageRepository;
import com.akash.imagerepository.jsp.repository.model.imageData;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@ContextConfiguration
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

public class ImageControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ImageRepository imageRepository;

    @Test
    @Order(1)
    public void whenAddImage_thenImageSaved() throws Exception {
        MockHttpServletRequestBuilder addBookRequest = MockMvcRequestBuilders.post("/image/addImage")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                .param("name", "gamesService")
                .param("size", String.valueOf(1000))
                .param("imageTag", "ABCD");
        mockMvc.perform(addBookRequest)
                .andReturn();

        Optional<imageData> storedImageOpt = imageRepository.findByTag("ABCD");
        assertTrue(storedImageOpt.isPresent());
        assertEquals("gameService", storedImageOpt.get()
                .getName());
        assertEquals(1000, storedImageOpt.get()
                .getSize());
    }

    @Test
    @Order(2)
    public void givenAlreadyExistingImage_whenAddImage_thenShowErrorPage() throws Exception {
        MockHttpServletRequestBuilder addImageRequest = MockMvcRequestBuilders.post("/image/addImage")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                .param("name", "gamesService")
                .param("size", String.valueOf(1000))
                .param("imageTag", "ABCD");
        ResultActions addImageResult = mockMvc.perform(addImageRequest);

        addImageResult.andExpect(view().name("error-image"))
                .andExpect(model().attribute("ref", "ABCD"))
                .andExpect(model().attribute("object", hasProperty("imageTag", equalTo("ABCD"))))
                .andExpect(model().attribute("message", "Cannot add an already existing book"));
    }

}
